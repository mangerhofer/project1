#include "Token.h"
#include <sstream>

using namespace std;

Token::Token(TokenType type, std::string description, unsigned int line) {
    this->type = type;
    this->description = description;
    this->line = line;
}

string Token::toString() {

    string typo;

    switch (type) {
        case TokenType::COMMA:
            typo = "COMMA";
            break;
         case TokenType::PERIOD:
             typo = "PERIOD";
             break;
         case TokenType::Q_MARK:
             typo = "Q_MARK";
             break;
         case TokenType::LEFT_PAREN:
             typo = "LEFT_PAREN";
             break;
         case TokenType::RIGHT_PAREN:
             typo = "RIGHT_PAREN";
             break;
         case TokenType::COLON:
             typo = "COLON";
             break;
         case TokenType::COLON_DASH:
             typo = "COLON_DASH";
             break;
         case TokenType::MULTIPLY:
             typo = "MULTIPLY";
             break;
         case TokenType::ADD:
             typo = "ADD";
             break;
         case TokenType::SCHEMES:
             typo = "SCHEMES";
             break;
         case TokenType::FACTS:
             typo = "FACTS";
             break;
         case TokenType::RULES:
             typo = "RULES";
             break;
         case TokenType::QUERIES:
             typo = "QUERIES";
             break;
         case TokenType::ID:
             typo = "ID";
             break;
         case TokenType::STRING:
             typo = "STRING";
             break;
         case TokenType::COMMENT:
             typo = "COMMENT";
             break;
         case TokenType::UNDEFINED:
             typo = "UNDEFINED";
             break;
         case TokenType::ENDFILE:
             typo = "EOF";
             break;
        default:
            break;
    }

    stringstream out;
    out << "(" << typo << "," << "\"" << description << "\"" << "," << line << ")";
    return out.str();
}