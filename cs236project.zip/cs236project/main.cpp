#include "Lexer.h"
#include "Token.h"
#include <string>
#include <fstream>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {
	string filename = argv[1];

    ifstream inputFile(argv[1]);
    string file;
    file.assign((istreambuf_iterator<char>(inputFile)),(istreambuf_iterator<char>()));
    
    Lexer* lexer = new Lexer();
    lexer->Run(file);
    lexer->toString();

    vector<Token*> tolkien = lexer->getTokens();
    
    delete lexer;

//    for (int i = 0; i < tolkien.size(); ++i) {
//        cout << tolkien[i]->toString() << endl;
//    }

    cout << "Total Tokens = " << tolkien.size();

    return 0;
}