//
// Created by McCall Angerhofer on 10/18/22.
//

#ifndef PROJECT1_STARTER_CODE_MUTLIPLYAUTOMATON_H
#define PROJECT1_STARTER_CODE_MUTLIPLYAUTOMATON_H

#include "Automaton.h"

using namespace std;

class MutliplyAutomaton : public Automaton {

public:
    MutliplyAutomaton() : Automaton(TokenType::MULTIPLY) {}  // Call the base constructor

    void S0(const std::string& input);

};


#endif //PROJECT1_STARTER_CODE_MUTLIPLYAUTOMATON_H
