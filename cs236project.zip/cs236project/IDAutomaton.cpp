//
// Created by McCall Angerhofer on 10/18/22.
//

#include "IDAutomaton.h"
#include <cctype>

using namespace std;

void IDAutomaton::S0(const std::string& input) {
    if (isalpha(input[index])) {
        inputRead++;
        index++;
        S1(input);
    }
    else {
        Serr();
    }
}

void IDAutomaton::S1(const std::string& input) {
    if (isalpha(input[index]) || isalnum(input[index])) {
        inputRead++;
    }
    else {
        Serr();
    }
}

